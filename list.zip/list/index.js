let arr= JSON.parse(localStorage.getItem("name"))|| []

function listmaker(){

let val=document.getElementById("names").value;
arr.push(val);
let inputval=""

for(i=0; i<arr.length; i++){

    inputval= inputval + arr[i] + "<br>";
}

document.getElementById("list").innerHTML=inputval;

}
document.getElementById("btn").addEventListener("click",listmaker)


function valid(){
    let val=document.getElementById("names").value;
    if(val===""){
        alert("enter a name")
        
    }

}

document.getElementById("btn").addEventListener("click",valid)


function cif(){
    document.getElementById("names").value="";

    
}



document.getElementById("btn").addEventListener("click",cif)


function addtostorage(){

    localStorage.setItem("name",JSON.stringify( arr))
}
document.getElementById("btn").addEventListener("click",addtostorage)




